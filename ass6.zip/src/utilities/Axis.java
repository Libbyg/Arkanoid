package utilities;

/**
 * enum for axis will bbe used for geometry shapes.
 */
public enum Axis {
    X, Y, YX, XY
}
