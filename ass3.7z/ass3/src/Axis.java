public enum Axis {
    X,Y,YX,XY
}
